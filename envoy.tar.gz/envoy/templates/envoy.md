# About Me

- Name:
- Alias:
- Role:
- Manager:
- Direct reports:
<!-- Populated by `envoy init` or Phonetool lookup -->

# Priorities

<!-- Your top priorities — the agent uses these to rank what matters -->

# High Priority People

<!-- People whose emails/Slack should always be flagged -->

# Preferences

## Email
- Ignore: vendor marketing, cold outreach
- KEEP by default — when in doubt, keep it

## Slack
- Favorite channels:

## Calendar
<!-- e.g., "no meetings before 9am", "block focus time Fridays" -->

## Signature
<!-- Appended to emails and Slack messages sent on your behalf -->

# Executive Assistant

- ea_alias:
- ea_name:
